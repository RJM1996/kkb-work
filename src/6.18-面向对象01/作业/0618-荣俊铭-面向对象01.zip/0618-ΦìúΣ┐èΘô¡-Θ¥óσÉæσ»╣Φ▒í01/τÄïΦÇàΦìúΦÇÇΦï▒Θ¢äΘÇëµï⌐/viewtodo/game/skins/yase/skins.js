/**
 * 亚瑟的皮肤
 */

export class Skin301660{
  constructor(){
      this.name = "皮肤01";
      this.ico = "./sources/skins/301660.png"
  }
}

export class Skin301661{
  constructor(){
      this.name = "皮肤02";
      this.ico = "./sources/skins/301661.png"
  }
}

export class Skin301662{
  constructor(){
      this.name = "皮肤03";
      this.ico = "./sources/skins/301662.png"
  }
}