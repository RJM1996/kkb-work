/**
 * 鲁班的技能
 */

export class S11210{
  constructor(){
      this.name = "河豚手雷";
      this.ico = "./sources/skills/11210.png"
  }
}

export class S11220{
  constructor(){
      this.name = "无敌鲨嘴炮";
      this.ico = "./sources/skills/11220.png"
  }
}

export class S11230{
  constructor(){
      this.name = "空中支援";
      this.ico = "./sources/skills/11230.png"
  }
}