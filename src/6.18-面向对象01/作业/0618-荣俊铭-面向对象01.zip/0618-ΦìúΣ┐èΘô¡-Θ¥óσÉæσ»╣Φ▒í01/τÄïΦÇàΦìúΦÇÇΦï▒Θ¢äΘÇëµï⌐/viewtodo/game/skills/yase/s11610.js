export default class S11610{
    constructor(){
        this.name = "誓约之盾";
        this.ico = "./sources/skills/16610.png"
    }
}