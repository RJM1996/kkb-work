/**
 * 鲁班的皮肤
 */

export class Skin301120{
  constructor(){
      this.name = "皮肤01";
      this.ico = "./sources/skins/301120.png"
  }
}

export class Skin301121{
  constructor(){
      this.name = "皮肤02";
      this.ico = "./sources/skins/301121.png"
  }
}

export class Skin301122{
  constructor(){
      this.name = "皮肤03";
      this.ico = "./sources/skins/301122.png"
  }
}