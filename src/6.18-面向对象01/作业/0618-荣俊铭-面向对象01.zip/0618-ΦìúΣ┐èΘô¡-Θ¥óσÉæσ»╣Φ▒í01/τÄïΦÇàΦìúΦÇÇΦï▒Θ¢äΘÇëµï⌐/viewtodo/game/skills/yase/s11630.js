export default class S11630{
    constructor(){
        this.name = "圣剑裁决";
        this.ico = "./sources/skills/16630.png"
    }
}