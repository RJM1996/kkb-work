import fn from "./fn";
import logo from "./images/logo.png";
import style from "./css/css.css";

const img = new Image();
img.src = logo;

document.body.appendChild(img);

console.log(fn);
