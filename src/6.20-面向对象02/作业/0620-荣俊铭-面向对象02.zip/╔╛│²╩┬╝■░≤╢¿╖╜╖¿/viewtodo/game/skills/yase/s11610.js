export default class S11610{
    constructor(){
        this.name = "技能一";
        this.ico = "./sources/skills/16610.png"
    }
}