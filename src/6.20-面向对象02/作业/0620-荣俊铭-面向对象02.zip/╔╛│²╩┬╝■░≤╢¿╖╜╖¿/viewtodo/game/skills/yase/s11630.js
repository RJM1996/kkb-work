export default class S11630{
    constructor(){
        this.name = "技能三";
        this.ico = "./sources/skills/16630.png"
    }
}