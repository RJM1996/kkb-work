export default class Skin1{
    constructor(){
        this.name = "皮肤一";
        this.ico = "./sources/heros/luban1.png";
        this.img = "./sources/skins/301120.png";
    }
}