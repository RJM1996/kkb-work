export const hello = function() {
  console.log('hello, world')
}